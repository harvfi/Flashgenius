import { GoogleGenAI, Type } from "@google/genai";
import { Card } from "../types";

// Using the provided environment variable for API key
const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

export const generateFlashcards = async (topic: string, count: number = 10): Promise<Omit<Card, 'id'>[]> => {
  if (!apiKey) {
    console.warn("API Key is missing. Returning mock data.");
    return [
      { front: "Error", back: "API Key missing. Please check configuration." },
    ];
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate ${count} flashcards about "${topic}". Create concise questions for the front and clear answers for the back.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              front: {
                type: Type.STRING,
                description: "The question or term on the front of the flashcard",
              },
              back: {
                type: Type.STRING,
                description: "The answer or definition on the back of the flashcard",
              },
            },
            required: ["front", "back"],
          },
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from AI");
    }

    const data = JSON.parse(text);
    return data;
  } catch (error) {
    console.error("Failed to generate flashcards:", error);
    throw error;
  }
};