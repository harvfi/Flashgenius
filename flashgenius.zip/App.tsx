import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Plus, ArrowLeft, Brain, Sparkles, Trash2, Edit3, X, Save, RotateCcw, ChevronLeft, ChevronRight, LayoutGrid, Globe, Lock, Search, User, Download, Share2, Clock, Repeat, ListTodo, Trophy, CheckCircle, XCircle } from 'lucide-react';
import { Deck, Card, ViewState, StudyMode } from './types';
import { generateFlashcards } from './services/geminiService';
import { Button } from './components/Button';
import { CardPreview } from './components/CardPreview';
import { StudyCard } from './components/StudyCard';

// Utility for safe ID generation
const generateId = () => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
};

// Mock Community Data
const MOCK_COMMUNITY_DECKS: Deck[] = [
  {
    id: 'comm-1',
    title: 'JavaScript Essentials',
    description: 'Core concepts including closures, hoisting, and ES6+ features.',
    author: 'CodeMaster99',
    isPublic: true,
    createdAt: Date.now() - 86400000 * 5,
    cards: [
      { id: 'c1', front: 'What is a Closure?', back: 'A closure is the combination of a function bundled together (enclosed) with references to its surrounding state (the lexical environment).' },
      { id: 'c2', front: 'What is Hoisting?', back: 'Hoisting is JavaScript\'s default behavior of moving declarations to the top.' },
      { id: 'c3', front: 'Difference between let and var?', back: 'let is block scoped, var is function scoped.' },
      { id: 'c4', front: 'What is the Event Loop?', back: 'The mechanism that handles asynchronous callbacks in JavaScript.' }
    ]
  },
  {
    id: 'comm-2',
    title: 'Spanish Common Phrases',
    description: 'Essential phrases for travelers.',
    author: 'LinguaFranca',
    isPublic: true,
    createdAt: Date.now() - 86400000 * 12,
    cards: [
      { id: 's1', front: 'Hello', back: 'Hola' },
      { id: 's2', front: 'Where is the bathroom?', back: '¿Dónde está el baño?' },
      { id: 's3', front: 'How much does it cost?', back: '¿Cuánto cuesta?' },
      { id: 's4', front: 'Thank you', back: 'Gracias' }
    ]
  },
  {
    id: 'comm-3',
    title: 'Periodic Table Elements',
    description: 'Symbols and Atomic Numbers for the first 20 elements.',
    author: 'ScienceWhiz',
    isPublic: true,
    createdAt: Date.now() - 86400000 * 20,
    cards: [
      { id: 'p1', front: 'H', back: 'Hydrogen (1)' },
      { id: 'p2', front: 'He', back: 'Helium (2)' },
      { id: 'p3', front: 'Li', back: 'Lithium (3)' },
      { id: 'p4', front: 'O', back: 'Oxygen (8)' }
    ]
  }
];

const INITIAL_DECK: Deck = {
  id: 'demo-deck',
  title: 'Capital Cities',
  description: 'Learn the capitals of the world',
  author: 'You',
  isPublic: false,
  createdAt: Date.now(),
  cards: [
    { id: '1', front: 'France', back: 'Paris' },
    { id: '2', front: 'Japan', back: 'Tokyo' },
    { id: '3', front: 'Brazil', back: 'Brasilia' },
  ]
};

interface DeckCardProps {
  deck: Deck;
  isCommunity?: boolean;
  onStartStudy: (deck: Deck) => void;
  onEdit: (deck: Deck) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
  onClone: (deck: Deck) => void;
}

const DeckCard: React.FC<DeckCardProps> = ({ 
  deck, 
  isCommunity = false, 
  onStartStudy, 
  onEdit, 
  onDelete, 
  onClone 
}) => (
  <div 
    className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-xl hover:border-indigo-200 transition-all duration-300 group cursor-pointer flex flex-col h-full"
    onClick={() => onStartStudy(deck)}
  >
    <div className="p-6 flex-1">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${isCommunity ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-700'}`}>
            {deck.cards.length}
          </div>
          {isCommunity && (
             <div className="flex flex-col">
                <span className="text-xs text-slate-400">by</span>
                <span className="text-xs font-semibold text-indigo-600">{deck.author || 'Anonymous'}</span>
             </div>
          )}
        </div>

        <div className="flex gap-1" onClick={e => e.stopPropagation()}>
           {!isCommunity && (
             <>
              <button onClick={() => onEdit(deck)} className="p-2 text-slate-400 hover:text-indigo-600 rounded-full hover:bg-slate-50 opacity-0 group-hover:opacity-100 transition-opacity">
                 <Edit3 size={18} />
               </button>
               <button onClick={(e) => onDelete(deck.id, e)} className="p-2 text-slate-400 hover:text-red-600 rounded-full hover:bg-slate-50 opacity-0 group-hover:opacity-100 transition-opacity">
                 <Trash2 size={18} />
               </button>
             </>
           )}
           {isCommunity && (
             <Button size="sm" variant="secondary" onClick={(e) => { e.stopPropagation(); onClone(deck); }} className="gap-1 text-xs px-2 py-1 h-8">
               <Download size={14} /> Save
             </Button>
           )}
        </div>
      </div>
      
      <div className="mb-2">
         <h3 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1" title={deck.title}>{deck.title}</h3>
         {!isCommunity && (
           <span className={`inline-flex items-center gap-1 text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full mt-1 ${deck.isPublic ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
             {deck.isPublic ? <Globe size={10} /> : <Lock size={10} />}
             {deck.isPublic ? 'Public' : 'Private'}
           </span>
         )}
      </div>
      
      <p className="text-slate-500 text-sm line-clamp-2">{deck.description || 'No description'}</p>
    </div>
    <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 rounded-b-xl flex justify-between items-center">
      <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">
        {new Date(deck.createdAt).toLocaleDateString()}
      </span>
      <span className="text-sm font-medium text-indigo-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
        Study Now <ChevronRight size={16} />
      </span>
    </div>
  </div>
);

const App: React.FC = () => {
  // State
  const [view, setView] = useState<ViewState>('dashboard');
  const [activeTab, setActiveTab] = useState<'my-decks' | 'community'>('my-decks');
  
  // Data
  const [decks, setDecks] = useState<Deck[]>(() => {
    const saved = localStorage.getItem('flashgenius_decks');
    return saved ? JSON.parse(saved) : [INITIAL_DECK];
  });
  
  // User Identity
  const [userName, setUserName] = useState(() => localStorage.getItem('flashgenius_username') || 'Anonymous');

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Editor State
  const [activeDeck, setActiveDeck] = useState<Deck | null>(null);
  const [editorDeckTitle, setEditorDeckTitle] = useState('');
  const [editorDeckDesc, setEditorDeckDesc] = useState('');
  const [editorIsPublic, setEditorIsPublic] = useState(false);
  const [editorCards, setEditorCards] = useState<Card[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationTopic, setGenerationTopic] = useState('');
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [currentFront, setCurrentFront] = useState('');
  const [currentBack, setCurrentBack] = useState('');

  // Search State
  const [searchQuery, setSearchQuery] = useState('');

  // Study State
  const [studyMode, setStudyMode] = useState<StudyMode>('standard');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  // Quiz Specific State
  const [quizOptions, setQuizOptions] = useState<string[]>([]);
  const [quizSelected, setQuizSelected] = useState<string | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizTimeLeft, setQuizTimeLeft] = useState(15);
  const [isQuizFinished, setIsQuizFinished] = useState(false);
  
  // Spaced Repetition State
  const [dueCards, setDueCards] = useState<Card[]>([]);

  // PWA Prompt Effect
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  // Persist Decks
  useEffect(() => {
    localStorage.setItem('flashgenius_decks', JSON.stringify(decks));
  }, [decks]);

  // Persist Username
  useEffect(() => {
    localStorage.setItem('flashgenius_username', userName);
  }, [userName]);

  // Derived State for Community
  const communityDecks = [
    ...MOCK_COMMUNITY_DECKS,
    ...decks.filter(d => d.isPublic)
  ].filter((deck, index, self) => index === self.findIndex((t) => t.id === deck.id));

  const filteredCommunityDecks = communityDecks.filter(d => 
    d.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    d.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (d.author && d.author.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // --- Logic: Quiz Mode ---

  const QUIZ_TIMER_DURATION = 15;

  const generateQuizOptions = useCallback((currentCard: Card, deck: Deck) => {
    const otherCards = deck.cards.filter(c => c.id !== currentCard.id);
    const shuffledOthers = [...otherCards].sort(() => 0.5 - Math.random());
    const distractors = shuffledOthers.slice(0, 3).map(c => c.back);
    
    // Fill with placeholders if not enough cards
    while (distractors.length < 3) {
      distractors.push(`Option ${distractors.length + 1}`);
    }

    const options = [...distractors, currentCard.back];
    return options.sort(() => 0.5 - Math.random());
  }, []);

  useEffect(() => {
    if (view === 'study' && studyMode === 'quiz' && activeDeck && !isQuizFinished) {
      const currentCard = activeDeck.cards[currentCardIndex];
      if (currentCard) {
        setQuizOptions(generateQuizOptions(currentCard, activeDeck));
        setQuizSelected(null);
        setQuizTimeLeft(QUIZ_TIMER_DURATION);
      }
    }
  }, [currentCardIndex, view, studyMode, activeDeck, isQuizFinished, generateQuizOptions]);

  useEffect(() => {
    let timer: any;
    if (view === 'study' && studyMode === 'quiz' && !quizSelected && !isQuizFinished && quizTimeLeft > 0) {
      timer = setInterval(() => {
        setQuizTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (quizTimeLeft === 0 && !quizSelected && !isQuizFinished) {
      // Time's up logic
      handleQuizAnswer('__TIMEOUT__');
    }
    return () => clearInterval(timer);
  }, [quizTimeLeft, quizSelected, view, studyMode, isQuizFinished]);

  const handleQuizAnswer = (answer: string) => {
    if (quizSelected || !activeDeck) return;
    
    setQuizSelected(answer);
    const currentCard = activeDeck.cards[currentCardIndex];
    const isCorrect = answer === currentCard.back;

    if (isCorrect) setQuizScore(prev => prev + 1);

    // Delay before next question
    setTimeout(() => {
      if (currentCardIndex < activeDeck.cards.length - 1) {
        setCurrentCardIndex(prev => prev + 1);
      } else {
        setIsQuizFinished(true);
      }
    }, 1500);
  };

  // --- Logic: Spaced Repetition ---

  const calculateSm2 = (card: Card, quality: number) => {
    // Default values if first time
    const prevRepetitions = card.repetitions || 0;
    const prevInterval = card.interval || 0; // minutes
    const prevEase = card.ease || 2.5;

    let newInterval = 0;
    let newRepetitions = 0;
    let newEase = prevEase;

    if (quality >= 3) { // 3 is pass threshold
      if (prevRepetitions === 0) {
        newInterval = 1; // 1 day (stored as 1440 mins usually, but lets keep simplistic: 10 mins for first pass)
        // Simplified for this app: first pass = 10 mins, second = 1 day
        newInterval = 10; 
      } else if (prevRepetitions === 1) {
        newInterval = 1440; // 1 day in mins
      } else {
        newInterval = Math.round(prevInterval * prevEase);
      }
      newRepetitions = prevRepetitions + 1;
      
      // Update Ease
      newEase = prevEase + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
      if (newEase < 1.3) newEase = 1.3;
    } else {
      newRepetitions = 0;
      newInterval = 1; // Reset to 1 min
    }

    return {
      repetitions: newRepetitions,
      interval: newInterval,
      ease: newEase,
      nextReview: Date.now() + (newInterval * 60 * 1000)
    };
  };

  const handleSpacedRating = (quality: number) => {
    if (!activeDeck || dueCards.length === 0) return;
    
    const currentCard = dueCards[currentCardIndex];
    const stats = calculateSm2(currentCard, quality);
    
    // Update card in decks state
    const updatedCard = { ...currentCard, ...stats, lastReviewed: Date.now() };
    
    // Update Main State
    setDecks(prev => prev.map(d => {
      if (d.id === activeDeck.id) {
        return {
          ...d,
          cards: d.cards.map(c => c.id === currentCard.id ? updatedCard : c)
        };
      }
      return d;
    }));

    // Move to next due card
    if (currentCardIndex < dueCards.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      // Finished all due cards
      alert("You've reviewed all due cards for now!");
      setView('dashboard');
    }
  };

  // --- Actions ---

  const handleCreateDeck = () => {
    setActiveDeck(null);
    setEditorDeckTitle('');
    setEditorDeckDesc('');
    setEditorIsPublic(false);
    setEditorCards([]);
    setGenerationTopic('');
    setView('editor');
  };

  const handleEditDeck = (deck: Deck) => {
    setActiveDeck(deck);
    setEditorDeckTitle(deck.title);
    setEditorDeckDesc(deck.description);
    setEditorIsPublic(deck.isPublic || false);
    setEditorCards([...deck.cards]);
    setGenerationTopic('');
    setView('editor');
  };

  const handleCloneDeck = (deck: Deck) => {
    if (window.confirm(`Add "${deck.title}" to your library?`)) {
      const newDeck: Deck = {
        ...deck,
        id: generateId(),
        author: userName,
        isPublic: false,
        createdAt: Date.now(),
        cards: deck.cards.map(c => ({...c, repetitions: 0, interval: 0, ease: 2.5, nextReview: 0})) // Reset study stats
      };
      setDecks(prev => [...prev, newDeck]);
      setActiveTab('my-decks');
      alert("Deck added to your library!");
    }
  };

  const handleDeleteDeck = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this deck?')) {
      setDecks(prev => prev.filter(d => d.id !== id));
    }
  };

  const handleStartStudy = (deck: Deck) => {
    if (deck.cards.length === 0) return;
    setActiveDeck(deck);
    setCurrentCardIndex(0);
    setIsFlipped(false);
    setStudyMode('standard'); // Default mode
    setQuizScore(0);
    setIsQuizFinished(false);
    setView('study');
  };

  const handleModeChange = (mode: StudyMode) => {
    if (!activeDeck) return;
    setStudyMode(mode);
    setCurrentCardIndex(0);
    setIsFlipped(false);
    
    if (mode === 'spaced') {
      const now = Date.now();
      const due = activeDeck.cards.filter(c => !c.nextReview || c.nextReview <= now);
      setDueCards(due);
    }
    
    if (mode === 'quiz') {
      setQuizScore(0);
      setIsQuizFinished(false);
    }
  };

  const saveDeck = () => {
    if (!editorDeckTitle.trim()) {
      alert("Please give your deck a title");
      return;
    }

    const newDeck: Deck = {
      id: activeDeck ? activeDeck.id : generateId(),
      title: editorDeckTitle,
      description: editorDeckDesc,
      cards: editorCards,
      createdAt: activeDeck ? activeDeck.createdAt : Date.now(),
      isPublic: editorIsPublic,
      author: activeDeck ? activeDeck.author : userName
    };

    setDecks(prev => {
      if (activeDeck) {
        return prev.map(d => d.id === activeDeck.id ? newDeck : d);
      }
      return [...prev, newDeck];
    });

    setView('dashboard');
  };

  // --- AI Generation ---

  const handleGenerateCards = async () => {
    if (!generationTopic.trim()) return;
    setIsGenerating(true);
    try {
      const generated = await generateFlashcards(generationTopic, 8);
      const newCards = generated.map(c => ({ ...c, id: generateId() }));
      setEditorCards(prev => [...prev, ...newCards]);
      setGenerationTopic('');
    } catch (error) {
      alert("Failed to generate cards. Please check your connection or try a different topic.");
    } finally {
      setIsGenerating(false);
    }
  };

  // --- Card Management ---

  const addManualCard = () => {
    if (!currentFront.trim() || !currentBack.trim()) return;
    
    if (editingCardId) {
      setEditorCards(prev => prev.map(c => 
        c.id === editingCardId ? { ...c, front: currentFront, back: currentBack } : c
      ));
      setEditingCardId(null);
    } else {
      setEditorCards(prev => [...prev, {
        id: generateId(),
        front: currentFront,
        back: currentBack
      }]);
    }
    setCurrentFront('');
    setCurrentBack('');
  };

  const editCard = (card: Card) => {
    setEditingCardId(card.id);
    setCurrentFront(card.front);
    setCurrentBack(card.back);
    const inputArea = document.getElementById('card-input-area');
    inputArea?.scrollIntoView({ behavior: 'smooth' });
  };

  const deleteCard = (id: string) => {
    setEditorCards(prev => prev.filter(c => c.id !== id));
  };

  // --- Views ---

  const renderDashboard = () => (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
            <Brain className="text-indigo-600" size={32} />
            FlashGenius
          </h1>
          <p className="text-slate-500 mt-2">Master any subject with AI-powered flashcards</p>
        </div>
        <div className="flex items-center gap-3">
           {deferredPrompt && (
              <Button onClick={handleInstallClick} variant="outline" className="hidden sm:flex items-center gap-2 border-indigo-200 text-indigo-700 bg-indigo-50 hover:bg-indigo-100">
                <Download size={18} />
                <span className="hidden md:inline">Install App</span>
              </Button>
           )}
           <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-white rounded-full border border-slate-200 shadow-sm">
              <User size={16} className="text-slate-400" />
              <input 
                type="text" 
                value={userName} 
                onChange={(e) => setUserName(e.target.value)}
                className="text-sm text-slate-700 outline-none w-24 bg-transparent"
                placeholder="Your Name"
              />
           </div>
           <Button onClick={handleCreateDeck} size="lg" className="shadow-lg shadow-indigo-200">
             <Plus className="mr-2" size={20} />
             Create
           </Button>
        </div>
      </header>

      {/* Tabs */}
      <div className="flex items-center gap-6 border-b border-slate-200 mb-8">
        <button 
          onClick={() => setActiveTab('my-decks')}
          className={`pb-4 text-sm font-medium transition-colors relative ${activeTab === 'my-decks' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
        >
          My Library
          {activeTab === 'my-decks' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 rounded-t-full" />}
        </button>
        <button 
          onClick={() => setActiveTab('community')}
          className={`pb-4 text-sm font-medium transition-colors relative flex items-center gap-2 ${activeTab === 'community' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <Globe size={16} />
          Community
          {activeTab === 'community' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 rounded-t-full" />}
        </button>
      </div>

      {activeTab === 'my-decks' && (
        decks.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
            <div className="bg-indigo-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <LayoutGrid className="text-indigo-400" size={32} />
            </div>
            <h3 className="text-xl font-medium text-slate-900">No decks yet</h3>
            <p className="text-slate-500 mt-2 max-w-sm mx-auto">Create your first deck manually or let our AI generate one for you instantly.</p>
            <Button onClick={handleCreateDeck} variant="secondary" className="mt-6">
              Get Started
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {decks.map(deck => (
              <DeckCard 
                key={deck.id} 
                deck={deck} 
                onStartStudy={handleStartStudy}
                onEdit={handleEditDeck}
                onDelete={handleDeleteDeck}
                onClone={handleCloneDeck}
              />
            ))}
          </div>
        )
      )}

      {activeTab === 'community' && (
        <div className="space-y-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search decks by title, topic or author..."
              className="w-full pl-12 pr-4 py-3 bg-white rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none shadow-sm transition-shadow"
            />
          </div>

          {filteredCommunityDecks.length === 0 ? (
             <div className="text-center py-20">
                <p className="text-slate-500">No community decks found matching "{searchQuery}".</p>
             </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCommunityDecks.map(deck => (
                <DeckCard 
                  key={deck.id} 
                  deck={deck} 
                  isCommunity={true}
                  onStartStudy={handleStartStudy}
                  onEdit={handleEditDeck}
                  onDelete={handleDeleteDeck}
                  onClone={handleCloneDeck}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderEditor = () => (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Editor Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => setView('dashboard')} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {activeDeck ? 'Edit Deck' : 'Create Deck'}
            </h2>
            <p className="text-xs text-slate-500">
              {editorCards.length} cards in deck
            </p>
          </div>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setView('dashboard')}>Cancel</Button>
          <Button onClick={saveDeck}>
            <Save className="mr-2" size={18} />
            Save Deck
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
        {/* Left Panel: Inputs */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-8">
          <div className="max-w-2xl mx-auto space-y-8">
            {/* Deck Info */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                 <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Deck Details</h3>
                 <label className="flex items-center gap-2 cursor-pointer relative group">
                    <input 
                      type="checkbox" 
                      checked={editorIsPublic}
                      onChange={e => setEditorIsPublic(e.target.checked)}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    <span className="text-sm font-medium text-slate-600 flex items-center gap-1">
                      {editorIsPublic ? <Globe size={14} className="text-indigo-600" /> : <Lock size={14} />}
                      {editorIsPublic ? 'Public' : 'Private'}
                    </span>
                 </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                <input
                  type="text"
                  value={editorDeckTitle}
                  onChange={e => setEditorDeckTitle(e.target.value)}
                  placeholder="e.g., Biology 101"
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                <textarea
                  value={editorDeckDesc}
                  onChange={e => setEditorDeckDesc(e.target.value)}
                  placeholder="What is this deck about?"
                  rows={2}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow resize-none"
                />
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <User size={16} />
                <span>Author: <span className="font-semibold text-slate-700">{activeDeck?.author || userName}</span></span>
              </div>
            </div>

            {/* AI Generator */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 rounded-xl shadow-lg text-white">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="text-yellow-300" size={20} />
                <h3 className="font-bold">Magic Generator</h3>
              </div>
              <p className="text-indigo-100 text-sm mb-4">
                Enter a topic, and our AI will instantly create a set of high-quality flashcards for you.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={generationTopic}
                  onChange={e => setGenerationTopic(e.target.value)}
                  placeholder="e.g., Photosynthesis, French Verbs, Quantum Physics"
                  className="flex-1 px-4 py-2 rounded-lg text-slate-900 border-0 focus:ring-2 focus:ring-white/50 outline-none placeholder:text-slate-400"
                  onKeyDown={e => e.key === 'Enter' && handleGenerateCards()}
                />
                <Button 
                  onClick={handleGenerateCards} 
                  isLoading={isGenerating} 
                  disabled={!generationTopic.trim()}
                  className="bg-white text-indigo-600 hover:bg-indigo-50 border-0"
                >
                  Generate
                </Button>
              </div>
            </div>

            {/* Manual Entry */}
            <div id="card-input-area" className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
               <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  {editingCardId ? 'Edit Card' : 'Add New Card'}
                </h3>
                {editingCardId && (
                  <button onClick={() => { setEditingCardId(null); setCurrentFront(''); setCurrentBack(''); }} className="text-xs text-red-500 hover:underline">
                    Cancel Edit
                  </button>
                )}
               </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Front</label>
                  <textarea
                    value={currentFront}
                    onChange={e => setCurrentFront(e.target.value)}
                    placeholder="Question or Term"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow resize-none bg-slate-50"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Back</label>
                  <textarea
                    value={currentBack}
                    onChange={e => setCurrentBack(e.target.value)}
                    placeholder="Answer or Definition"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow resize-none bg-slate-50"
                  />
                </div>
              </div>
              <div className="flex justify-end pt-2">
                <Button onClick={addManualCard} disabled={!currentFront.trim() || !currentBack.trim()}>
                  {editingCardId ? 'Update Card' : 'Add Card'}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: List */}
        <div className="lg:w-96 lg:h-full h-64 bg-slate-100 border-t lg:border-t-0 lg:border-l border-slate-200 flex flex-col flex-shrink-0">
          <div className="p-4 border-b border-slate-200 bg-white">
            <h3 className="font-bold text-slate-700">Cards ({editorCards.length})</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {editorCards.length === 0 ? (
              <div className="text-center text-slate-400 py-10 px-4">
                <p>No cards yet.</p>
                <p className="text-sm mt-1">Add them manually or use the generator.</p>
              </div>
            ) : (
              editorCards.map((card, idx) => (
                <CardPreview 
                  key={card.id} 
                  card={card} 
                  index={idx} 
                  onDelete={deleteCard}
                  onEdit={editCard}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );

  // --- Sub-View: Standard Study ---
  const renderStandardStudy = (deck: Deck) => {
    const currentCard = deck.cards[currentCardIndex];
    if (!currentCard) return <div className="p-10 text-center">No cards available</div>;
    
    const progress = Math.round(((currentCardIndex + 1) / deck.cards.length) * 100);

    return (
      <>
        {/* Progress Bar */}
        <div className="h-1 bg-slate-200 w-full">
           <div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>

        {/* Card Area */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 overflow-hidden">
          <StudyCard 
            card={currentCard} 
            isFlipped={isFlipped} 
            onFlip={() => setIsFlipped(!isFlipped)} 
          />
        </div>

        {/* Controls */}
        <div className="bg-white px-6 py-6 border-t border-slate-200 flex justify-center items-center gap-8">
           <button 
             onClick={() => {
                if (currentCardIndex > 0) {
                  setCurrentCardIndex(prev => prev - 1);
                  setIsFlipped(false);
                }
             }}
             disabled={currentCardIndex === 0}
             className="p-4 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
           >
             <ChevronLeft size={24} />
           </button>

           <div className="text-sm font-medium text-slate-400">
              {currentCardIndex + 1} / {deck.cards.length}
           </div>

           <button 
             onClick={() => {
                if (currentCardIndex < deck.cards.length - 1) {
                  setCurrentCardIndex(prev => prev + 1);
                  setIsFlipped(false);
                }
             }}
             disabled={currentCardIndex === deck.cards.length - 1}
             className="p-4 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
           >
             <ChevronRight size={24} />
           </button>
        </div>
      </>
    );
  };

  // --- Sub-View: Spaced Repetition Study ---
  const renderSpacedStudy = () => {
    if (dueCards.length === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
            <CheckCircle size={40} />
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-2">All Caught Up!</h3>
          <p className="text-slate-500 max-w-md mb-8">
            You have reviewed all pending cards for now. Great job keeping up with your streak!
          </p>
          <Button onClick={() => setView('dashboard')}>Back to Dashboard</Button>
          <button onClick={() => handleModeChange('standard')} className="mt-4 text-indigo-600 hover:underline text-sm font-medium">
             Continue reviewing (Standard Mode)
          </button>
        </div>
      );
    }

    const currentCard = dueCards[currentCardIndex];
    if (!currentCard) return null; // Should be handled by length check

    return (
      <>
         <div className="bg-amber-50 border-b border-amber-100 px-4 py-2 text-center text-xs font-medium text-amber-800 flex items-center justify-center gap-2">
           <Repeat size={12} />
           Spaced Repetition: {dueCards.length - currentCardIndex} cards due
         </div>
         
         <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 overflow-hidden">
          <StudyCard 
            card={currentCard} 
            isFlipped={isFlipped} 
            onFlip={() => setIsFlipped(!isFlipped)} 
          />
        </div>

        {/* SR Controls */}
        <div className="bg-white px-6 py-6 border-t border-slate-200">
           {!isFlipped ? (
             <div className="flex justify-center">
                <Button onClick={() => setIsFlipped(true)} size="lg" className="w-full max-w-xs">Show Answer</Button>
             </div>
           ) : (
             <div className="grid grid-cols-4 gap-2 max-w-2xl mx-auto">
               <button onClick={() => handleSpacedRating(1)} className="flex flex-col items-center p-3 rounded-xl bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 transition-colors">
                 <span className="font-bold">Again</span>
                 <span className="text-[10px] opacity-75 mt-1">&lt; 1m</span>
               </button>
               <button onClick={() => handleSpacedRating(3)} className="flex flex-col items-center p-3 rounded-xl bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors">
                 <span className="font-bold">Hard</span>
                 <span className="text-[10px] opacity-75 mt-1">1d</span>
               </button>
               <button onClick={() => handleSpacedRating(4)} className="flex flex-col items-center p-3 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition-colors">
                 <span className="font-bold">Good</span>
                 <span className="text-[10px] opacity-75 mt-1">Next</span>
               </button>
               <button onClick={() => handleSpacedRating(5)} className="flex flex-col items-center p-3 rounded-xl bg-green-50 text-green-700 hover:bg-green-100 border border-green-200 transition-colors">
                 <span className="font-bold">Easy</span>
                 <span className="text-[10px] opacity-75 mt-1">Later</span>
               </button>
             </div>
           )}
        </div>
      </>
    );
  };

  // --- Sub-View: Quiz Mode ---
  const renderQuizStudy = (deck: Deck) => {
    if (isQuizFinished) {
       return (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50">
          <div className="w-24 h-24 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-6 animate-bounce">
            <Trophy size={48} />
          </div>
          <h3 className="text-3xl font-bold text-slate-900 mb-2">Quiz Complete!</h3>
          <p className="text-slate-500 mb-8 text-lg">
            You scored <span className="font-bold text-indigo-600">{quizScore}</span> out of <span className="font-bold">{deck.cards.length}</span>
          </p>
          <div className="flex gap-4">
             <Button onClick={() => handleStartStudy(deck)} variant="secondary">Retry Quiz</Button>
             <Button onClick={() => setView('dashboard')}>Back to Dashboard</Button>
          </div>
        </div>
       );
    }
    
    const currentCard = deck.cards[currentCardIndex];
    if (!currentCard) return null;

    return (
      <>
        {/* Quiz Header */}
        <div className="bg-white px-4 py-3 border-b border-slate-200 flex justify-between items-center shadow-sm z-10">
           <div className="text-sm font-semibold text-slate-500">
             Question {currentCardIndex + 1} / {deck.cards.length}
           </div>
           <div className={`flex items-center gap-2 font-mono font-bold text-lg ${quizTimeLeft < 5 ? 'text-red-500 animate-pulse' : 'text-slate-700'}`}>
             <Clock size={20} />
             00:{quizTimeLeft.toString().padStart(2, '0')}
           </div>
           <div className="text-sm font-semibold text-indigo-600">
             Score: {quizScore}
           </div>
        </div>

        {/* Question Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center max-w-3xl mx-auto w-full">
           <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-8 w-full mb-8 text-center min-h-[200px] flex items-center justify-center">
              <h2 className="text-2xl md:text-3xl font-medium text-slate-800">{currentCard.front}</h2>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
              {quizOptions.map((option, idx) => {
                 let btnClass = "p-6 rounded-xl border-2 text-left transition-all duration-200 font-medium text-slate-700 flex items-center justify-between group ";
                 const isSelected = quizSelected === option;
                 const isCorrectAnswer = option === currentCard.back;
                 
                 if (quizSelected) {
                    if (isCorrectAnswer) {
                       btnClass += "bg-green-50 border-green-500 text-green-800";
                    } else if (isSelected && !isCorrectAnswer) {
                       btnClass += "bg-red-50 border-red-500 text-red-800";
                    } else {
                       btnClass += "bg-slate-50 border-slate-200 opacity-50";
                    }
                 } else {
                    btnClass += "bg-white border-slate-200 hover:border-indigo-400 hover:shadow-md cursor-pointer";
                 }

                 return (
                   <button 
                     key={idx} 
                     onClick={() => handleQuizAnswer(option)}
                     disabled={!!quizSelected}
                     className={btnClass}
                   >
                     <span className="line-clamp-2">{option}</span>
                     {quizSelected && isCorrectAnswer && <CheckCircle className="text-green-600 flex-shrink-0 ml-2" />}
                     {quizSelected && isSelected && !isCorrectAnswer && <XCircle className="text-red-600 flex-shrink-0 ml-2" />}
                   </button>
                 );
              })}
           </div>
        </div>
      </>
    );
  };

  const renderStudy = () => {
    if (!activeDeck) return null;

    return (
      <div className="h-screen flex flex-col bg-slate-100">
        {/* Study Header */}
        <div className="bg-white px-6 py-4 flex items-center justify-between border-b border-slate-200 shadow-sm z-20 relative">
          <button onClick={() => setView('dashboard')} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors">
            <X size={20} className="mr-2" />
            <span className="font-medium hidden md:inline">Exit</span>
          </button>
          
          <div className="flex bg-slate-100 p-1 rounded-lg">
             <button 
                onClick={() => handleModeChange('standard')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${studyMode === 'standard' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
             >
                Standard
             </button>
             <button 
                onClick={() => handleModeChange('spaced')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-1 ${studyMode === 'spaced' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
             >
                <Repeat size={14} /> Smart Review
             </button>
             <button 
                onClick={() => handleModeChange('quiz')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-1 ${studyMode === 'quiz' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
             >
                <ListTodo size={14} /> Quiz
             </button>
          </div>

          <button onClick={() => { setCurrentCardIndex(0); setIsFlipped(false); setQuizScore(0); setIsQuizFinished(false); }} className="p-2 text-slate-400 hover:text-indigo-600 transition-colors" title="Restart">
            <RotateCcw size={20} />
          </button>
        </div>

        {studyMode === 'standard' && renderStandardStudy(activeDeck)}
        {studyMode === 'spaced' && renderSpacedStudy()}
        {studyMode === 'quiz' && renderQuizStudy(activeDeck)}
      </div>
    );
  };

  // Keyboard Shortcuts for Study Mode
  useEffect(() => {
    if (view !== 'study' || !activeDeck || studyMode === 'quiz') return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault(); 
        setIsFlipped(prev => !prev);
      } else if (e.code === 'ArrowRight' && studyMode === 'standard') {
         if (currentCardIndex < activeDeck.cards.length - 1) {
            setCurrentCardIndex(prev => prev + 1);
            setIsFlipped(false);
         }
      } else if (e.code === 'ArrowLeft' && studyMode === 'standard') {
         if (currentCardIndex > 0) {
            setCurrentCardIndex(prev => prev - 1);
            setIsFlipped(false);
         }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [view, activeDeck, currentCardIndex, studyMode]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {view === 'dashboard' && renderDashboard()}
      {view === 'editor' && renderEditor()}
      {view === 'study' && renderStudy()}
    </div>
  );
};

export default App;