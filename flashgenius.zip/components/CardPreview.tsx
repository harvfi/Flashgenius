import React from 'react';
import { Card } from '../types';
import { Trash2, Edit2 } from 'lucide-react';

interface CardPreviewProps {
  card: Card;
  index: number;
  onDelete: (id: string) => void;
  onEdit: (card: Card) => void;
}

export const CardPreview: React.FC<CardPreviewProps> = ({ card, index, onDelete, onEdit }) => {
  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 hover:shadow-md transition-shadow group">
      <div className="flex justify-between items-start mb-2">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Card {index + 1}</span>
        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={() => onEdit(card)}
            className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
            title="Edit card"
          >
            <Edit2 size={16} />
          </button>
          <button 
            onClick={() => onDelete(card.id)}
            className="p-1 text-slate-400 hover:text-red-600 transition-colors"
            title="Delete card"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
      <div className="space-y-3">
        <div>
          <div className="text-xs text-slate-500 mb-1">Front</div>
          <p className="text-sm font-medium text-slate-800 line-clamp-2">{card.front}</p>
        </div>
        <div className="h-px bg-slate-100" />
        <div>
          <div className="text-xs text-slate-500 mb-1">Back</div>
          <p className="text-sm text-slate-600 line-clamp-3">{card.back}</p>
        </div>
      </div>
    </div>
  );
};