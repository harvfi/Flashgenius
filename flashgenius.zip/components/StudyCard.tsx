import React, { useState, useEffect } from 'react';
import { Card } from '../types';

interface StudyCardProps {
  card: Card;
  isFlipped: boolean;
  onFlip: () => void;
}

export const StudyCard: React.FC<StudyCardProps> = ({ card, isFlipped, onFlip }) => {
  return (
    <div 
      className="relative w-full max-w-2xl aspect-[3/2] cursor-pointer perspective-1000 group"
      onClick={onFlip}
    >
      <div 
        className={`w-full h-full duration-500 transform-style-3d transition-transform ${isFlipped ? 'rotate-y-180' : ''}`}
      >
        {/* Front */}
        <div className="absolute w-full h-full backface-hidden bg-white rounded-2xl shadow-xl flex flex-col items-center justify-center p-8 border border-slate-100">
          <span className="absolute top-6 left-6 text-xs font-bold text-slate-300 tracking-widest uppercase">Question</span>
          <p className="text-2xl md:text-3xl text-center font-medium text-slate-800">
            {card.front}
          </p>
          <span className="absolute bottom-6 text-sm text-slate-400 opacity-50">Click to flip</span>
        </div>

        {/* Back */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-indigo-50 rounded-2xl shadow-xl flex flex-col items-center justify-center p-8 border border-indigo-100">
          <span className="absolute top-6 left-6 text-xs font-bold text-indigo-300 tracking-widest uppercase">Answer</span>
          <p className="text-xl md:text-2xl text-center text-slate-800 leading-relaxed">
            {card.back}
          </p>
        </div>
      </div>
    </div>
  );
};