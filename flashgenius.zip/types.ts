export interface Card {
  id: string;
  front: string;
  back: string;
  // Spaced Repetition Stats
  lastReviewed?: number;
  nextReview?: number;
  interval?: number; // Current interval in minutes
  ease?: number; // Ease factor (default 2.5)
  repetitions?: number;
}

export interface Deck {
  id: string;
  title: string;
  description: string;
  cards: Card[];
  createdAt: number;
  author?: string;
  isPublic?: boolean;
}

export type ViewState = 'dashboard' | 'editor' | 'study';

export type StudyMode = 'standard' | 'spaced' | 'quiz';

export interface GenerationRequest {
  topic: string;
  count: number;
}